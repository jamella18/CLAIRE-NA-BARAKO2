<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/helpers.php';

$error = null;
$success = false;
$token = $_GET['token'] ?? '';

if ($token === '') {
    $error = 'Invalid or missing reset token.';
} else {
    // Verify token
    $stmt = db()->prepare(
        'SELECT prt.*, u.id as user_id, u.email 
         FROM password_reset_tokens prt 
         JOIN users u ON prt.user_id = u.id 
         WHERE prt.token = :token AND prt.used = 0 AND prt.expires_at > NOW()'
    );
    $stmt->execute([':token' => $token]);
    $reset = $stmt->fetch();

    if (!$reset) {
        $error = 'Invalid or expired reset token. Please request a new one.';
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if ($password === '' || strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            // Update password
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt = db()->prepare('UPDATE users SET password = :password WHERE id = :user_id');
            $stmt->execute([
                ':password' => $hashed,
                ':user_id' => $reset['user_id'],
            ]);

            // Mark token as used
            $stmt = db()->prepare('UPDATE password_reset_tokens SET used = 1 WHERE token = :token');
            $stmt->execute([':token' => $token]);

            $success = true;
        }
    }
}
?>

<section class="card auth-card">
    <h1>Reset Password</h1>
    
    <?php if ($error): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($error); ?></div>
        <div class="auth-actions">
            <a href="<?php echo site_url('forgot_password.php'); ?>">Request New Reset Link</a>
        </div>
    <?php elseif ($success): ?>
        <div class="alert" style="background: #d4edda; color: #155724;" data-flash>
            Password reset successfully! <a href="<?php echo site_url('login.php'); ?>">Login now</a>.
        </div>
    <?php elseif ($token): ?>
        <p>Enter your new password below.</p>
        <form method="post" class="form">
            <label>
                New Password
                <input type="password" name="password" required minlength="6" autofocus>
            </label>
            <label>
                Confirm Password
                <input type="password" name="confirm_password" required minlength="6">
            </label>
            <button class="btn" type="submit">Reset Password</button>
        </form>
        <div class="auth-actions">
            <a href="<?php echo site_url('login.php'); ?>">Back to Login</a>
        </div>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

