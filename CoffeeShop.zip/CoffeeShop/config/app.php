<?php
declare(strict_types=1);

/**
 * Base URL of the CoffeeShop project relative to the web root.
 * Adjust if you deploy under a different directory/virtual host.
 */
const BASE_URL = '/CoffeeShop';

function site_url(string $path = ''): string
{
    $base = rtrim(BASE_URL, '/');
    $path = ltrim($path, '/');

    return $path === '' ? $base . '/' : "{$base}/{$path}";
}

function asset_url(string $path): string
{
    return site_url('assets/' . ltrim($path, '/'));
}

function redirect_to(string $path): void
{
    header('Location: ' . site_url($path));
    exit;
}

