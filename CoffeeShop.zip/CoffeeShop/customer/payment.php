<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$orderId = (int) ($_GET['order_id'] ?? 0);
$order = fetch_order($orderId, current_user()['id']);

if (!$order) {
    http_response_code(404);
    exit('Order not found');
}

$reference = $order['payment_reference'] ?? 'GCASH-' . strtoupper(substr(md5($order['id'] . time()), 0, 8));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = db()->prepare(
        'UPDATE orders SET payment_status = "paid", payment_reference = :ref WHERE id = :id'
    );
    $stmt->execute([':ref' => $reference, ':id' => $order['id']]);

    $paymentStmt = db()->prepare(
        'INSERT INTO payments (order_id, amount, reference, status) VALUES (:order, :amount, :ref, "paid")
         ON DUPLICATE KEY UPDATE status = "paid", reference = :ref'
    );
    $paymentStmt->execute([
        ':order' => $order['id'],
        ':amount' => $order['total'],
        ':ref' => $reference,
    ]);

    redirect_to("customer/invoice.php?id={$order['id']}");
}
?>

<section class="card">
    <h1>GCash Payment</h1>
    <p>Order #: <?php echo $order['id']; ?></p>
    <p>Amount: <?php echo format_currency((float) $order['total']); ?></p>
    <p>Reference: <strong><?php echo $reference; ?></strong></p>
    <form method="post">
        <button class="btn" type="submit">Mark as Paid</button>
        <a class="btn-secondary" href="<?php echo site_url('customer/order_history.php'); ?>">Cancel</a>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

