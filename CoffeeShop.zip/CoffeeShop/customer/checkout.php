<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$user = current_user();
$cart = $_SESSION['cart'] ?? [];

if (!$cart) {
    redirect_to('customer/menu.php');
}

$ids = implode(',', array_map('intval', array_keys($cart)));
$stmt = db()->query("SELECT * FROM products WHERE id IN ($ids)");
$products = $stmt->fetchAll();

$items = [];
$total = 0;

foreach ($products as $product) {
    $qty = $cart[$product['id']];
    $lineTotal = $product['price'] * $qty;
    $items[] = ['product' => $product, 'qty' => $qty, 'total' => $lineTotal];
    $total += $lineTotal;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $notes = trim($_POST['notes'] ?? '');

    $orderStmt = db()->prepare(
        'INSERT INTO orders (user_id, total, notes) VALUES (:user, :total, :notes)'
    );
    $orderStmt->execute([
        ':user'  => $user['id'],
        ':total' => $total,
        ':notes' => $notes,
    ]);

    $orderId = (int) db()->lastInsertId();

    $itemStmt = db()->prepare(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (:order, :product, :qty, :price)'
    );

    foreach ($items as $item) {
        $itemStmt->execute([
            ':order'   => $orderId,
            ':product' => $item['product']['id'],
            ':qty'     => $item['qty'],
            ':price'   => $item['product']['price'],
        ]);
    }

    $_SESSION['cart'] = [];

    redirect_to("customer/payment.php?order_id={$orderId}");
}
?>

<section class="card">
    <h1>Checkout</h1>
    <table>
        <thead>
        <tr>
            <th>Drink</th>
            <th>Qty</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['product']['name']); ?></td>
                <td><?php echo $item['qty']; ?></td>
                <td><?php echo format_currency((float) $item['total']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><strong>Amount Due: <?php echo format_currency((float) $total); ?></strong></p>
    <form method="post">
        <label>
            Notes
            <textarea name="notes" rows="3"></textarea>
        </label>
        <button class="btn" type="submit">Confirm & Pay with GCash</button>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

