<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$user = current_user();
$orders = fetch_recent_orders((int) $user['id']);
?>

<section class="card">
    <h1>Welcome back, <?php echo htmlspecialchars($user['name']); ?></h1>
    <p>Track your active orders, reorder favorites, and manage your profile.</p>
    <div class="grid">
        <a class="btn" href="<?php echo site_url('customer/menu.php'); ?>">Order Coffee</a>
        <a class="btn-secondary" href="<?php echo site_url('customer/order_tracking.php'); ?>">Track Order</a>
    </div>
</section>

<section class="card">
    <h2>Recent Orders</h2>
    <?php if ($orders): ?>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Placed</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?php echo $order['id']; ?></td>
                        <td><?php echo ucfirst($order['status']); ?></td>
                        <td><?php echo format_currency((float) $order['total']); ?></td>
                        <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                        <td><a class="btn-secondary" href="<?php echo site_url('customer/invoice.php?id=' . $order['id']); ?>">View</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No orders yet. <a href="<?php echo site_url('customer/menu.php'); ?>">Place your first order.</a></p>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

