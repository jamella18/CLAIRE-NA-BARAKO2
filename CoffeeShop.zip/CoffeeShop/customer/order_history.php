<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$stmt = db()->prepare('SELECT * FROM orders WHERE user_id = :user ORDER BY created_at DESC');
$stmt->execute([':user' => current_user()['id']]);
$orders = $stmt->fetchAll();
?>

<section class="card">
    <h1>Order History</h1>
    <?php if ($orders): ?>
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Total</th>
                <th>Date</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo ucfirst($order['status']); ?></td>
                    <td><?php echo ucfirst($order['payment_status']); ?></td>
                    <td><?php echo format_currency((float) $order['total']); ?></td>
                    <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                    <td><a class="btn-secondary" href="<?php echo site_url('customer/invoice.php?id=' . $order['id']); ?>">Invoice</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No past orders.</p>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

