<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$orderId = (int) ($_GET['id'] ?? 0);
$order = fetch_order($orderId, current_user()['id']);

if (!$order) {
    http_response_code(404);
    exit('Order not found');
}

$items = fetch_order_items($orderId);
?>

<section class="card">
    <h1>Invoice #<?php echo $order['id']; ?></h1>
    <p>Status: <?php echo ucfirst($order['status']); ?> | Payment: <?php echo ucfirst($order['payment_status']); ?></p>
    <table>
        <thead>
        <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Price</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                <td><?php echo $item['quantity']; ?></td>
                <td><?php echo format_currency((float) $item['price']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><strong>Total Paid: <?php echo format_currency((float) $order['total']); ?></strong></p>
    <a class="btn" href="<?php echo site_url('customer/order_history.php'); ?>">Back to history</a>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

