<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_STAFF);

$inventory = fetch_inventory();
?>

<section class="card">
    <h1>Inventory Status</h1>
    <p>View current stock levels and low stock alerts.</p>
    <table>
        <thead>
        <tr>
            <th>Product</th>
            <th>Stock</th>
            <th>Threshold</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($inventory as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                <td><?php echo $item['stock']; ?></td>
                <td><?php echo $item['threshold']; ?></td>
                <td>
                    <?php if ($item['stock'] <= $item['threshold']): ?>
                        <span style="color: #d32f2f; font-weight: bold;">⚠ Low Stock</span>
                    <?php else: ?>
                        <span style="color: #388e3c;">✓ In Stock</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

