<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/helpers.php';

$search = trim($_GET['search'] ?? '');
$category = trim($_GET['category'] ?? '');

$products = fetch_products();

// Filter products
if ($search || $category) {
    $filtered = [];
    foreach ($products as $product) {
        $matchSearch = !$search || stripos($product['name'], $search) !== false || stripos($product['description'], $search) !== false;
        $matchCategory = !$category || $product['category'] === $category;
        if ($matchSearch && $matchCategory) {
            $filtered[] = $product;
        }
    }
    $products = $filtered;
}

$categories = array_unique(array_column(fetch_products(), 'category'));
?>

<section class="card">
    <h2>Search & Filter Products</h2>
    <form method="get" class="form search-form">
        <label>
            Search
            <input type="text" name="search" placeholder="Search by name or description..." value="<?php echo htmlspecialchars($search); ?>">
        </label>
        <label>
            Category
            <select name="category">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </label>
        <div class="filter-actions">
            <button class="btn btn-sm" type="submit">Search</button>
            <?php if ($search || $category): ?>
                <a class="btn-secondary btn-sm" href="<?php echo site_url(); ?>">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</section>

<section class="card">
    <h2><?php echo $search || $category ? 'Search Results' : 'Popular Picks'; ?></h2>
    <?php if ($products): ?>
        <div class="grid grid-3">
            <?php foreach (array_slice($products, 0, 12) as $product): ?>
                <?php
                $image = $product['image']
                    ? site_url($product['image'])
                    : asset_url('images/default-coffee.svg');
                ?>
                <article class="card product-card">
                    <img src="<?php echo htmlspecialchars($image); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p><?php echo htmlspecialchars($product['description']); ?></p>
                    <p><strong><?php echo format_currency((float) $product['price']); ?></strong></p>
                    <?php
                    $inventory = fetch_inventory();
                    $stock = null;
                    foreach ($inventory as $inv) {
                        if ((int)$inv['product_id'] === (int)$product['id']) {
                            $stock = (int)$inv['stock'];
                            break;
                        }
                    }
                    ?>
                    <p><small>Stock: <?php echo $stock !== null ? $stock : 'N/A'; ?></small></p>
                </article>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No products found. Try adjusting your search or filters.</p>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

