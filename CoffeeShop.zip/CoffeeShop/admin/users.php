<?php
require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_ADMIN);

$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['user_id'] ?? 0);
    $role = $_POST['role'] ?? ROLE_CUSTOMER;

    $stmt = db()->prepare('UPDATE users SET role = :role WHERE id = :id');
    $stmt->execute([':role' => $role, ':id' => $id]);
    $message = 'Role updated.';
}

$users = db()->query('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC')->fetchAll();
?>

<section class="card">
    <h1>User Management</h1>
    <?php if ($message): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <table>
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Joined</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo htmlspecialchars($user['name']); ?></td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td><?php echo ucfirst($user['role']); ?></td>
                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <select name="role">
                            <?php foreach ([ROLE_CUSTOMER, ROLE_STAFF, ROLE_ADMIN] as $role): ?>
                                <option value="<?php echo $role; ?>" <?php echo $role === $user['role'] ? 'selected' : ''; ?>>
                                    <?php echo ucfirst($role); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn-secondary" type="submit">Save</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>

