<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';

session_start();

const ROLE_CUSTOMER = 'customer';
const ROLE_ADMIN = 'admin';
const ROLE_STAFF = 'staff';

function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

function login_user(array $user): void
{
    $_SESSION['user'] = $user;
}

function logout_user(): void
{
    $_SESSION = [];
    session_destroy();
}

function require_login(?string $role = null): void
{
    $user = current_user();

    if (!$user) {
        redirect_to('login.php');
    }

    if ($role && ($user['role'] ?? null) !== $role) {
        http_response_code(403);
        exit('Access denied');
    }
}

