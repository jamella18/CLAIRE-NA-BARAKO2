<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Coffee Shop</title>
        <link rel="stylesheet" href="<?php echo asset_url('css/style.css'); ?>">
    </head>
    <body<?php 
        $authPages = ['login.php', 'register.php', 'forgot_password.php', 'reset_password.php'];
        if (in_array(basename($_SERVER['PHP_SELF']), $authPages)) {
            echo ' class="auth-page"';
        }
    ?>>
        <header class="site-header">
            <div class="brand">
                <a href="<?php echo site_url(); ?>">Coffee Shop</a>
            </div>
            <nav>
                <?php 
                $user = current_user();
                $role = $user['role'] ?? null;
                ?>
                
                <?php if ($role === ROLE_ADMIN): ?>
                    <a href="<?php echo site_url(); ?>">Home</a>
                    <a href="<?php echo site_url('admin/dashboard.php'); ?>">Admin</a>
                    <a href="<?php echo site_url('admin/orders.php'); ?>">Orders</a>
                    <a href="<?php echo site_url('admin/menu.php'); ?>">Menu</a>
                    <a href="<?php echo site_url('admin/users.php'); ?>">Users</a>
                    <a href="<?php echo site_url('admin/inventory.php'); ?>">Inventory</a>
                    <a href="<?php echo site_url('admin/reports.php'); ?>">Reports</a>
                    <a href="<?php echo site_url('logout.php'); ?>">Logout</a>
                <?php elseif ($role === ROLE_STAFF): ?>
                    <a href="<?php echo site_url(); ?>">Home</a>
                    <a href="<?php echo site_url('staff/dashboard.php'); ?>">Dashboard</a>
                    <a href="<?php echo site_url('staff/orders.php'); ?>">Orders</a>
                    <a href="<?php echo site_url('staff/inventory.php'); ?>">Inventory</a>
                    <a href="<?php echo site_url('logout.php'); ?>">Logout</a>
                <?php elseif ($role === ROLE_CUSTOMER): ?>
                    <a href="<?php echo site_url(); ?>">Home</a>
                    <a href="<?php echo site_url('customer/menu.php'); ?>">Menu</a>
                    <a href="<?php echo site_url('customer/dashboard.php'); ?>">Dashboard</a>
                    <a href="<?php echo site_url('customer/cart.php'); ?>">Cart</a>
                    <a href="<?php echo site_url('customer/order_tracking.php'); ?>">Track Order</a>
                    <a href="<?php echo site_url('customer/profile.php'); ?>">Profile</a>
                    <a href="<?php echo site_url('logout.php'); ?>">Logout</a>
                <?php else: ?>
                    <a href="<?php echo site_url('login.php'); ?>">Login</a>
                    <a href="<?php echo site_url('register.php'); ?>">Register</a>
                <?php endif; ?>
            </nav>
        </header>
        <main class="page-container">

