<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/helpers.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT * FROM users WHERE email = :email');
    $stmt->execute([':email' => $email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        login_user($user);
        if ($user['role'] === ROLE_ADMIN) {
            redirect_to('admin/dashboard.php');
        } elseif ($user['role'] === ROLE_STAFF) {
            redirect_to('staff/dashboard.php');
        } else {
            redirect_to('customer/dashboard.php');
        }
    }

    $error = 'Invalid credentials.';
}
?>

<section class="card auth-card">
    <h1>Welcome back</h1>
    <p>Sign in to manage your orders and enjoy fast checkout.</p>
    <?php if ($error): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form method="post" class="form">
        <label>
            Email
            <input type="email" name="email" required>
        </label>
        <label>
            Password
            <input type="password" name="password" required>
        </label>
        <button class="btn" type="submit">Sign In</button>
    </form>
    <div class="auth-actions">
        <div>
            <span>New here?</span>
            <a href="<?php echo site_url('register.php'); ?>">Create account</a>
        </div>
        <div>
            <a href="<?php echo site_url('forgot_password.php'); ?>">Forgot password?</a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

