<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_STAFF);

$user = current_user();

// Get today's orders
$todayOrders = db()->query(
    "SELECT COUNT(*) AS count FROM orders WHERE DATE(created_at) = CURDATE()"
)->fetch()['count'];

// Get pending orders
$pendingOrders = db()->query(
    "SELECT COUNT(*) AS count FROM orders WHERE status IN ('pending', 'confirmed', 'brewing')"
)->fetch()['count'];

// Get ready orders
$readyOrders = db()->query(
    "SELECT COUNT(*) AS count FROM orders WHERE status = 'ready'"
)->fetch()['count'];
?>

<section class="card">
    <h1>Staff Dashboard</h1>
    <p>Welcome, <?php echo htmlspecialchars($user['name']); ?>! Manage today's orders and keep the coffee flowing.</p>
    <div class="grid grid-3">
        <div class="card">
            <h3>Today's Orders</h3>
            <p style="font-size: 2rem; margin: 0.5rem 0;"><?php echo $todayOrders; ?></p>
        </div>
        <div class="card">
            <h3>Pending</h3>
            <p style="font-size: 2rem; margin: 0.5rem 0;"><?php echo $pendingOrders; ?></p>
        </div>
        <div class="card">
            <h3>Ready</h3>
            <p style="font-size: 2rem; margin: 0.5rem 0;"><?php echo $readyOrders; ?></p>
        </div>
    </div>
</section>

<section class="card">
    <h2>Quick Actions</h2>
    <div class="grid">
        <a class="btn" href="<?php echo site_url('staff/orders.php'); ?>">Manage Orders</a>
        <a class="btn-secondary" href="<?php echo site_url('staff/inventory.php'); ?>">View Inventory</a>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

