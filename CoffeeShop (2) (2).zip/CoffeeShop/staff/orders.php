<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_STAFF);

$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? 'pending';

    $stmt = db()->prepare('UPDATE orders SET status = :status WHERE id = :id');
    $stmt->execute([':status' => $status, ':id' => $id]);
    $message = 'Order status updated.';
    redirect_to('staff/orders.php');
}

// Get active orders (pending, confirmed, brewing, ready)
$orders = db()->query(
    "SELECT o.*, u.name AS customer 
     FROM orders o 
     JOIN users u ON u.id = o.user_id 
     WHERE o.status IN ('pending', 'confirmed', 'brewing', 'ready')
     ORDER BY 
        CASE o.status
            WHEN 'ready' THEN 1
            WHEN 'brewing' THEN 2
            WHEN 'confirmed' THEN 3
            WHEN 'pending' THEN 4
        END,
        o.created_at ASC"
)->fetchAll();
?>

<section class="card">
    <h1>Order Management Queue</h1>
    <?php if ($message): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    
    <?php if ($orders): ?>
        <table>
            <thead>
            <tr>
                <th>#</th>
                <th>Customer</th>
                <th>Status</th>
                <th>Total</th>
                <th>Placed</th>
                <th>Update Status</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo htmlspecialchars($order['customer']); ?></td>
                    <td><strong><?php echo ucfirst($order['status']); ?></strong></td>
                    <td><?php echo format_currency((float) $order['total']); ?></td>
                    <td><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
                    <td>
                        <form method="post" class="inline-form">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <select name="status">
                                <?php foreach (['pending', 'confirmed', 'brewing', 'ready', 'completed'] as $status): ?>
                                    <option value="<?php echo $status; ?>" <?php echo $status === $order['status'] ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($status); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn-secondary" type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No active orders at the moment.</p>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

