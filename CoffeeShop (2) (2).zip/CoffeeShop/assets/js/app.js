document.addEventListener('DOMContentLoaded', () => {
    const alerts = document.querySelectorAll('[data-flash]');
    alerts.forEach((alert) => {
        setTimeout(() => alert.remove(), 4000);
    });

    // Logout confirmation dialog
    const logoutLinks = document.querySelectorAll('a[href*="logout.php"]');
    logoutLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            showLogoutDialog(link.href);
        });
    });
});

function showLogoutDialog(logoutUrl) {
    // Create dialog overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; display: flex; align-items: center; justify-content: center;';
    
    // Create dialog box
    const dialog = document.createElement('div');
    dialog.style.cssText = 'background: white; padding: 2rem; border-radius: 10px; max-width: 400px; width: 90%; box-shadow: 0 5px 20px rgba(0,0,0,0.3);';
    
    dialog.innerHTML = `
        <h2 style="margin-top: 0; color: #2f241f;">Confirm Logout</h2>
        <p style="color: #5b4638; margin-bottom: 1.5rem;">Are you sure you want to logout?</p>
        <div style="display: flex; gap: 1rem; justify-content: flex-end;">
            <button class="btn-secondary" id="cancelLogout" style="padding: 0.65rem 1.5rem; border: none; border-radius: 6px; cursor: pointer; background: #c0a080; color: #1d1d1f;">Cancel</button>
            <button class="btn" id="confirmLogout" style="padding: 0.65rem 1.5rem; border: none; border-radius: 6px; cursor: pointer; background: #7a4f29; color: #fff;">Logout</button>
        </div>
    `;
    
    overlay.appendChild(dialog);
    document.body.appendChild(overlay);
    
    // Handle cancel
    document.getElementById('cancelLogout').addEventListener('click', () => {
        document.body.removeChild(overlay);
    });
    
    // Handle confirm
    document.getElementById('confirmLogout').addEventListener('click', () => {
        window.location.href = logoutUrl;
    });
    
    // Close on overlay click
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            document.body.removeChild(overlay);
        }
    });
}

