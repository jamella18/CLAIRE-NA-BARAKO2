<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/helpers.php';

$message = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if ($email === '') {
        $error = 'Please enter your email address.';
    } else {
        $stmt = db()->prepare('SELECT id, name, email FROM users WHERE email = :email');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if ($user) {
            // Generate secure token
            $token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Delete old tokens for this user
            $stmt = db()->prepare('DELETE FROM password_reset_tokens WHERE user_id = :user_id');
            $stmt->execute([':user_id' => $user['id']]);

            // Insert new token
            $stmt = db()->prepare(
                'INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (:user_id, :token, :expires_at)'
            );
            $stmt->execute([
                ':user_id' => $user['id'],
                ':token' => $token,
                ':expires_at' => $expires_at,
            ]);

            // In production, send email with reset link
            // For now, we'll show the link (for development/testing)
            $reset_url = site_url('reset_password.php?token=' . $token);
            $message = 'Password reset link generated. <a href="' . htmlspecialchars($reset_url) . '">Click here to reset your password</a> (valid for 1 hour).';
            
            // In production, uncomment this and remove the message above:
            // mail($user['email'], 'Password Reset', "Click here to reset: $reset_url");
            // $message = 'If that email exists, we sent a password reset link.';
        } else {
            // Don't reveal if email exists (security best practice)
            $message = 'If that email exists, we sent a password reset link.';
        }
    }
}
?>

<section class="card auth-card">
    <h1>Forgot Password</h1>
    <p>Enter your email address and we'll send you a link to reset your password.</p>
    
    <?php if ($error): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if ($message): ?>
        <div class="alert" data-flash><?php echo $message; ?></div>
    <?php endif; ?>
    
    <form method="post" class="form">
        <label>
            Email Address
            <input type="email" name="email" required autofocus>
        </label>
        <button class="btn" type="submit">Send Reset Link</button>
    </form>
    
    <div class="auth-actions">
        <a href="<?php echo site_url('login.php'); ?>">Back to Login</a>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

