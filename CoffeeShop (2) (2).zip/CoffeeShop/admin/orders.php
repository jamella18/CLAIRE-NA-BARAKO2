<?php
require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_ADMIN);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int) ($_POST['order_id'] ?? 0);
    $status = $_POST['status'] ?? 'pending';

    $stmt = db()->prepare('UPDATE orders SET status = :status WHERE id = :id');
    $stmt->execute([':status' => $status, ':id' => $id]);
}

$orders = db()->query(
    'SELECT o.*, u.name AS customer FROM orders o JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC'
)->fetchAll();
?>

<section class="card">
    <h1>Order Management Queue</h1>
    <table>
        <thead>
        <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Status</th>
            <th>Total</th>
            <th>Placed</th>
            <th>Update</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($orders as $order): ?>
            <tr>
                <td><?php echo $order['id']; ?></td>
                <td><?php echo htmlspecialchars($order['customer']); ?></td>
                <td><?php echo ucfirst($order['status']); ?></td>
                <td><?php echo format_currency((float) $order['total']); ?></td>
                <td><?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></td>
                <td>
                    <form method="post" class="inline-form">
                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                        <select name="status">
                            <?php foreach (['pending','confirmed','brewing','ready','completed','cancelled'] as $status): ?>
                                <option value="<?php echo $status; ?>" <?php echo $status === $order['status'] ? 'selected' : ''; ?>>
                                    <?php echo ucfirst($status); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn-secondary" type="submit">Update</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>

