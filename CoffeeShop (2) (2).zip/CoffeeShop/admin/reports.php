<?php
require_once __DIR__ . '/../includes/admin_header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_ADMIN);

$sales = db()->query(
    'SELECT DATE(created_at) AS day, SUM(total) AS total FROM orders GROUP BY day ORDER BY day DESC LIMIT 30'
)->fetchAll();

$inventory = fetch_inventory();
?>

<section class="card">
    <h1>Sales & Inventory Reports</h1>
    <h2>Sales (30 days)</h2>
    <table>
        <thead>
        <tr>
            <th>Date</th>
            <th>Total Sales</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($sales as $row): ?>
            <tr>
                <td><?php echo $row['day']; ?></td>
                <td><?php echo format_currency((float) $row['total']); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>

<section class="card">
    <h2>Inventory Health</h2>
    <table>
        <thead>
        <tr>
            <th>Product</th>
            <th>Stock</th>
            <th>Threshold</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($inventory as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                <td><?php echo $item['stock']; ?></td>
                <td><?php echo $item['threshold']; ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</section>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>

