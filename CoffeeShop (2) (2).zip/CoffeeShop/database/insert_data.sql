-- Insert Users
INSERT INTO users (name, email, password, role, phone) VALUES
('Admin User', 'admin@coffee.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '09171234567'),
('Staff User', 'staff@coffee.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'staff', '09170001111'),
('Demo Customer', 'customer@coffee.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', '09175557777');

-- Insert Products
INSERT INTO products (name, description, price, category, is_available, image) VALUES
('Iced Latte', 'Espresso with milk over ice', 150, 'Cold Brew', 1, 'assets/images/iced-latte.svg'),
('Spanish Latte', 'Sweet creamy latte', 170, 'Signature', 1, 'assets/images/spanish-latte.svg'),
('Americano', 'Hot espresso with water', 120, 'Hot Coffee', 1, 'assets/images/americano.svg');

-- Insert Inventory (using product names to find IDs)
INSERT INTO inventory (product_id, product_name, stock, threshold)
SELECT id, name, 
    CASE name
        WHEN 'Iced Latte' THEN 40
        WHEN 'Spanish Latte' THEN 30
        WHEN 'Americano' THEN 50
    END as stock,
    CASE name
        WHEN 'Iced Latte' THEN 5
        WHEN 'Spanish Latte' THEN 5
        WHEN 'Americano' THEN 8
    END as threshold
FROM products
WHERE name IN ('Iced Latte', 'Spanish Latte', 'Americano');

