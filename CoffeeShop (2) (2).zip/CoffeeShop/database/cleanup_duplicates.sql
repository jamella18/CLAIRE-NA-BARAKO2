-- Cleanup Duplicate Products and Inventory
-- Run this to remove duplicates and keep only the first set

-- Remove duplicate inventory entries (keep IDs 7,8,9, remove 10,11,12)
DELETE FROM inventory WHERE id IN (10, 11, 12);

-- Remove duplicate products (keep IDs 4,5,6, remove 7,8,9)
-- First, we need to update inventory to reference the correct products
UPDATE inventory SET product_id = 4 WHERE product_id = 7;
UPDATE inventory SET product_id = 5 WHERE product_id = 8;
UPDATE inventory SET product_id = 6 WHERE product_id = 9;

-- Now delete duplicate products
DELETE FROM products WHERE id IN (7, 8, 9);

-- Reset AUTO_INCREMENT to prevent gaps (optional but clean)
ALTER TABLE products AUTO_INCREMENT = 10;
ALTER TABLE inventory AUTO_INCREMENT = 13;

