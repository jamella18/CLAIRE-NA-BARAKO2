<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/helpers.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
        $errors[] = 'All required fields must be filled.';
    }

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = :email');
        $stmt->execute([':email' => $email]);

        if ($stmt->fetch()) {
            $errors[] = 'Email already registered.';
        } else {
            $stmt = db()->prepare(
                'INSERT INTO users (name, email, phone, password, role) VALUES (:name, :email, :phone, :password, :role)'
            );
            $stmt->execute([
                ':name'     => $name,
                ':email'    => $email,
                ':phone'    => $phone,
                ':password' => password_hash($password, PASSWORD_BCRYPT),
                ':role'     => ROLE_CUSTOMER,
            ]);
            $success = true;
        }
    }
}
?>

<section class="card auth-card">
    <h1>Create an account</h1>
    <p>Save your favorites, reorder in a tap, and pay via GCash.</p>
    <?php foreach ($errors as $error): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($error); ?></div>
    <?php endforeach; ?>
    <?php if ($success): ?>
        <div class="alert" data-flash>Registration successful. <a href="<?php echo site_url('login.php'); ?>">Login now</a>.</div>
    <?php endif; ?>
    <form method="post" class="form">
        <label>
            Full Name *
            <input type="text" name="name" required value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
        </label>
        <label>
            Email *
            <input type="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
        </label>
        <label>
            Phone
            <input type="text" name="phone" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
        </label>
        <label>
            Password *
            <input type="password" name="password" required>
        </label>
        <button class="btn" type="submit">Sign Up</button>
    </form>
    <div class="auth-actions">
        <span>Already registered?</span>
        <a href="<?php echo site_url('login.php'); ?>">Login</a>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

