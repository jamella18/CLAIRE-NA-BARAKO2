<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$products = fetch_products();
?>

<section class="card">
    <h1>Menu</h1>
    <p>Select a drink to add to your cart.</p>
    <div class="grid grid-3">
        <?php foreach ($products as $product): ?>
            <form class="card" method="post" action="<?php echo site_url('customer/cart.php'); ?>">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                <p><?php echo htmlspecialchars($product['description']); ?></p>
                <p><strong><?php echo format_currency((float) $product['price']); ?></strong></p>
                <label>
                    Quantity
                    <input type="number" name="quantity" min="1" value="1">
                </label>
                <button class="btn" type="submit" name="action" value="add">Add to Cart</button>
            </form>
        <?php endforeach; ?>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

