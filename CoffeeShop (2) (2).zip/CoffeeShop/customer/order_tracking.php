<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$tracking = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = (int) ($_POST['order_id'] ?? 0);
    $tracking = fetch_order($orderId, current_user()['id']);
}
?>

<section class="card">
    <h1>Track Order</h1>
    <form method="post" class="form">
        <label>
            Enter Order #:
            <input type="number" name="order_id" required placeholder="Enter your order number">
        </label>
        <button class="btn" type="submit">Check Status</button>
    </form>

    <?php if ($tracking): ?>
        <div class="card" style="margin-top: 1.5rem; background: #f8f5f2; border-left: 4px solid #7a4f29;">
            <h3>Order #<?php echo $tracking['id']; ?></h3>
            <div style="display: grid; gap: 0.75rem; margin-top: 1rem;">
                <p><strong>Status:</strong> <span style="color: #7a4f29; font-weight: bold;"><?php echo ucfirst($tracking['status']); ?></span></p>
                <p><strong>Payment:</strong> <?php echo ucfirst($tracking['payment_status']); ?></p>
                <p><strong>Placed:</strong> <?php echo date('M d, Y h:i A', strtotime($tracking['created_at'])); ?></p>
                <?php if ($tracking['total']): ?>
                    <p><strong>Total:</strong> <?php echo format_currency((float) $tracking['total']); ?></p>
                <?php endif; ?>
            </div>
            <div style="margin-top: 1rem;">
                <a class="btn" href="<?php echo site_url('customer/invoice.php?id=' . $tracking['id']); ?>">View Invoice</a>
            </div>
        </div>
    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <div class="alert" style="margin-top: 1.5rem;">
            Order not found. Please check your order number and try again.
        </div>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

