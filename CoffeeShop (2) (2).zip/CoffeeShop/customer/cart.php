<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = (int) ($_POST['product_id'] ?? 0);
    $quantity = max(1, (int) ($_POST['quantity'] ?? 1));
    $action = $_POST['action'] ?? 'add';

    if ($productId) {
        if ($action === 'remove') {
            unset($_SESSION['cart'][$productId]);
        } else {
            $_SESSION['cart'][$productId] = $quantity;
        }
    }
    redirect_to('customer/cart.php');
}

$cartItems = [];
$total = 0;

if ($_SESSION['cart']) {
    $ids = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
    $stmt = db()->query("SELECT * FROM products WHERE id IN ($ids)");
    $products = $stmt->fetchAll();

    foreach ($products as $product) {
        $qty = $_SESSION['cart'][$product['id']];
        $lineTotal = $product['price'] * $qty;
        $total += $lineTotal;
        $cartItems[] = ['product' => $product, 'qty' => $qty, 'total' => $lineTotal];
    }
}
?>

<section class="card">
    <h1>Your Cart</h1>
    <?php if ($cartItems): ?>
        <table>
            <thead>
            <tr>
                <th>Drink</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($cartItems as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product']['name']); ?></td>
                    <td><?php echo $item['qty']; ?></td>
                    <td><?php echo format_currency((float) $item['product']['price']); ?></td>
                    <td><?php echo format_currency((float) $item['total']); ?></td>
                    <td>
                        <form method="post">
                            <input type="hidden" name="product_id" value="<?php echo $item['product']['id']; ?>">
                            <button class="btn-secondary" name="action" value="remove">Remove</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p><strong>Grand Total: <?php echo format_currency((float) $total); ?></strong></p>
        <a class="btn" href="<?php echo site_url('customer/checkout.php'); ?>">Proceed to Checkout</a>
    <?php else: ?>
        <p>Your cart is empty. <a href="<?php echo site_url('customer/menu.php'); ?>">Add drinks.</a></p>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

