<?php
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/helpers.php';

require_login(ROLE_CUSTOMER);

$user = current_user();
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    $stmt = db()->prepare('UPDATE users SET name = :name, phone = :phone WHERE id = :id');
    $stmt->execute([
        ':name' => $name,
        ':phone' => $phone,
        ':id' => $user['id'],
    ]);

    $_SESSION['user']['name'] = $name;
    $_SESSION['user']['phone'] = $phone;
    $message = 'Profile updated.';
}
?>

<section class="card">
    <h1>Profile Settings</h1>
    <p>Update your personal information and account details.</p>
    <?php if ($message): ?>
        <div class="alert" data-flash><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <form method="post" class="form" style="max-width: 500px;">
        <label>
            Full Name
            <input type="text" name="name" required value="<?php echo htmlspecialchars($user['name']); ?>">
        </label>
        <label>
            Email
            <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled style="background: #f5f5f5; cursor: not-allowed;">
            <small style="color: #888; font-size: 0.85rem;">Email cannot be changed</small>
        </label>
        <label>
            Phone Number
            <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="09171234567">
        </label>
        <div style="margin-top: 1rem;">
            <button class="btn" type="submit">Save Changes</button>
            <a class="btn-secondary" href="<?php echo site_url('customer/dashboard.php'); ?>" style="margin-left: 0.5rem;">Cancel</a>
        </div>
    </form>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

