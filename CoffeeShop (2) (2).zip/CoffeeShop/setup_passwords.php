<?php
/**
 * Run this script once to update user passwords with proper hashes
 * Usage: php setup_passwords.php
 */

require_once __DIR__ . '/config/database.php';

$passwords = [
    'admin@coffee.test' => 'admin123',
    'staff@coffee.test' => 'staff123',
    'customer@coffee.test' => 'customer123',
];

try {
    $pdo = db();
    
    foreach ($passwords as $email => $password) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('UPDATE users SET password = :password WHERE email = :email');
        $stmt->execute([
            ':password' => $hash,
            ':email' => $email,
        ]);
        echo "✓ Updated password for: $email\n";
    }
    
    echo "\n✓ All passwords updated successfully!\n";
    echo "\nYou can now login with:\n";
    echo "  Admin: admin@coffee.test / admin123\n";
    echo "  Staff: staff@coffee.test / staff123\n";
    echo "  Customer: customer@coffee.test / customer123\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

