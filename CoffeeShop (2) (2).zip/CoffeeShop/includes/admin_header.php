<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Coffee Shop - Admin</title>
        <link rel="stylesheet" href="<?php echo asset_url('css/style.css'); ?>">
    </head>
    <body class="admin-layout">
        <div class="admin-wrapper">
            <aside class="admin-sidebar">
                <div class="sidebar-brand">
                    <a href="<?php echo site_url('admin/dashboard.php'); ?>">Coffee Shop</a>
                    <span class="sidebar-subtitle">Admin Panel</span>
                </div>
                <nav class="sidebar-nav">
                    <a href="<?php echo site_url('admin/dashboard.php'); ?>" class="sidebar-link <?php echo (strpos($_SERVER['REQUEST_URI'], 'dashboard.php') !== false) ? 'active' : ''; ?>">
                        <span>📊</span> Dashboard
                    </a>
                    <a href="<?php echo site_url('admin/orders.php'); ?>" class="sidebar-link <?php echo (strpos($_SERVER['REQUEST_URI'], 'orders.php') !== false) ? 'active' : ''; ?>">
                        <span>📦</span> Orders
                    </a>
                    <a href="<?php echo site_url('admin/menu.php'); ?>" class="sidebar-link <?php echo (strpos($_SERVER['REQUEST_URI'], 'menu.php') !== false) ? 'active' : ''; ?>">
                        <span>☕</span> Menu
                    </a>
                    <a href="<?php echo site_url('admin/users.php'); ?>" class="sidebar-link <?php echo (strpos($_SERVER['REQUEST_URI'], 'users.php') !== false) ? 'active' : ''; ?>">
                        <span>👥</span> Users
                    </a>
                    <a href="<?php echo site_url('admin/inventory.php'); ?>" class="sidebar-link <?php echo (strpos($_SERVER['REQUEST_URI'], 'inventory.php') !== false) ? 'active' : ''; ?>">
                        <span>📋</span> Inventory
                    </a>
                    <a href="<?php echo site_url('admin/reports.php'); ?>" class="sidebar-link <?php echo (strpos($_SERVER['REQUEST_URI'], 'reports.php') !== false) ? 'active' : ''; ?>">
                        <span>📈</span> Reports
                    </a>
                </nav>
                <div class="sidebar-footer">
                    <a href="<?php echo site_url(); ?>" class="sidebar-link">
                        <span>🏠</span> View Site
                    </a>
                    <a href="<?php echo site_url('logout.php'); ?>" class="sidebar-link logout-link">
                        <span>🚪</span> Logout
                    </a>
                </div>
            </aside>
            <div class="admin-content">
                <header class="admin-topbar">
                    <h1><?php 
                        $page = basename($_SERVER['PHP_SELF']);
                        $titles = [
                            'dashboard.php' => 'Admin Dashboard',
                            'orders.php' => 'Order Management',
                            'menu.php' => 'Menu Management',
                            'users.php' => 'User Management',
                            'inventory.php' => 'Inventory Management',
                            'reports.php' => 'Sales & Reports'
                        ];
                        echo $titles[$page] ?? 'Admin Panel';
                    ?></h1>
                    <div class="admin-user">
                        <span><?php echo htmlspecialchars(current_user()['name'] ?? 'Admin'); ?></span>
                    </div>
                </header>
                <main class="admin-main">

