        </main>
        <footer class="site-footer">
            <p>&copy; <?php echo date('Y'); ?> Coffee Shop. All rights reserved.</p>
        </footer>
        <script src="<?php echo asset_url('js/app.js'); ?>"></script>
    </body>
</html>

