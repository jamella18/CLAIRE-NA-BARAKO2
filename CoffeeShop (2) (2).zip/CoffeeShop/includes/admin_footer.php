                </main>
                <footer class="admin-footer">
                    <p>&copy; <?php echo date('Y'); ?> Coffee Shop. All rights reserved.</p>
                </footer>
            </div>
        </div>
        <script src="<?php echo asset_url('js/app.js'); ?>"></script>
    </body>
</html>

