<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';

function fetch_products(): array
{
    $stmt = db()->query('SELECT * FROM products ORDER BY category, name');
    return $stmt->fetchAll();
}

function fetch_recent_orders(int $userId, int $limit = 5): array
{
    $stmt = db()->prepare(
        'SELECT * FROM orders WHERE user_id = :id ORDER BY created_at DESC LIMIT :limit'
    );
    $stmt->bindValue(':id', $userId, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function fetch_order(int $orderId, int $userId = null): ?array
{
    $sql = 'SELECT * FROM orders WHERE id = :id';
    if ($userId) {
        $sql .= ' AND user_id = :user_id';
    }

    $stmt = db()->prepare($sql);
    $stmt->bindValue(':id', $orderId, PDO::PARAM_INT);

    if ($userId) {
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
    }

    $stmt->execute();
    $order = $stmt->fetch();

    return $order ?: null;
}

function fetch_order_items(int $orderId): array
{
    $stmt = db()->prepare(
        'SELECT oi.*, p.name AS product_name 
         FROM order_items oi 
         JOIN products p ON p.id = oi.product_id
         WHERE order_id = :id'
    );
    $stmt->bindValue(':id', $orderId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

function fetch_inventory(): array
{
    $stmt = db()->query('SELECT * FROM inventory ORDER BY product_name');
    return $stmt->fetchAll();
}

function format_currency(float $value): string
{
    return '₱' . number_format($value, 2);
}

function current_path(): string
{
    return parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
}

